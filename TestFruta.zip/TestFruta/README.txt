=============PROYECTO PAGINA WEB HTML DURAZNO==============================
===Contenido===
Proyecto creado a modo de practica, contiene 5 archivos html donde cada uno es una pagina especifica
siendo index.html la pagina principal. En la carpeta css se encuentran los archivos .css que contienen
los diseños de cada pagina, el pie de las paginas, el menu y algunas especificaciones mas detalladas
en cada archivo style de su respectiva pagina.
==Instalar archivos==
1.-Descargar Visual Studio Code
2.-Arrastrar el archivo Index.html a la aplicacion
3.-En caso de que el paso 2 no funcione, hacer lo siguiente:
 3.1.-abrir Visual Studio Code
 3.2.-Seleccionar File-->Open Workspace--> Seleccionar carpeta contenedora de los archivos.
Fin.
==Pruebas==
==Despliegue==
==Construido con==
Se utilizo HTML para crear la estructura de la pagina, junto con CSS para establecer los deseños
de dicha pagina
==Contribuyendo==
==Autores==
-Adlai CG.-
==Licencia==
==Gratitud==
